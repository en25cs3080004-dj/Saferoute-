let checkTimer = null;
let remaining = 120;
function showTime() {
  const el = document.getElementById("timer");
  if (el) el.textContent = `Time remaining: ${Math.floor(remaining/60)}:${String(remaining%60).padStart(2,"0")}`;
}
function startCheck() {
  if (checkTimer) clearInterval(checkTimer);
  remaining = 120;
  const btn = document.getElementById("safeBtn");
  if (btn) btn.disabled = false;
  showTime();
  checkTimer = setInterval(async () => {
    remaining--;
    showTime();
    if (remaining <= 0) {
      clearInterval(checkTimer); checkTimer = null;
      if (btn) btn.disabled = true;
      await postAlert("AUTO_ESCALATION", "No response to the 2-minute safety check.");
      alert("Safety check timed out. An alert was recorded in SafeRoute. External contacts have NOT been notified.");
    }
  }, 1000);
}
function confirmSafe() {
  if (checkTimer) clearInterval(checkTimer);
  checkTimer = null;
  const el = document.getElementById("timer");
  if (el) el.textContent = "Check-in completed — glad you're safe.";
  const btn = document.getElementById("safeBtn");
  if (btn) btn.disabled = true;
}
async function postAlert(type, message) {
  let coords = {};
  if (navigator.geolocation) {
    try {
      const pos = await new Promise((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, {timeout:5000})
      );
      coords = {latitude: pos.coords.latitude, longitude: pos.coords.longitude};
    } catch (_) {}
  }
  const response = await fetch("/api/alert", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({type, message, ...coords})
  });
  return response.json();
}
async function sendSOS() {
  if (!confirm("Record an SOS alert in SafeRoute? This prototype does not call emergency services or send SMS.")) return;
  try {
    await postAlert("SOS", "User pressed the SOS button.");
    alert("SOS recorded in your SafeRoute dashboard. Contact your local emergency service directly if you are in immediate danger.");
  } catch (_) { alert("Could not record the alert. Please contact emergency services directly if needed."); }
}
